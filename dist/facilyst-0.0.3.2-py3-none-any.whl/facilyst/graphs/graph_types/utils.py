"""Utility functions for all graph types."""
